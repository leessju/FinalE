//
//  StreamingKitMac.h
//  StreamingKitMac
//
//  Created by Thong Nguyen on 02/02/2014.
//  Copyright (c) 2014 Thong Nguyen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StreamingKitMac : NSObject

@end
